﻿namespace StorageMaster.Entities.Products
{
	public class HardDrive : Product
	{
		public HardDrive(double price)
			: base(price, 1)
		{
		}
	}
}