﻿using System;

namespace StorageMester.BusinessLogic.Tests
{
    public class Class1
    {
    }
}
