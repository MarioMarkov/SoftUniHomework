﻿using NUnit.Framework;
using StorageMaster.Entities.Products;
using System;
using System.Linq;
using System.Reflection;

namespace StorageMester.Tests.Structure
{
    [TestFixture]
    public class Class1
    {
        [Test]
        public void DoesProductConstructorExists()
        {
            //Arrange
            Type type = typeof(Product);
            //Act
            ConstructorInfo[] constructors =type.GetConstructors(BindingFlags.Instance |BindingFlags.Public |BindingFlags.NonPublic);
            var constructor = constructors.First();
            //Assert
            Assert.IsNotNull(constructor);
        }
        [Test]
        public void DoesProductConstructorExists()
        {
            //Arrange
            Type type = typeof(Product);
            //Act
            ConstructorInfo[] constructors = type.GetConstructors(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            var constructor = constructors.First();
            //Assert
            Assert.IsNotNull(constructor);
        }
    }
}
