﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=DESKTOP-9JPDD1J;Database=VaporStore;Trusted_Connection=True";
	}
}