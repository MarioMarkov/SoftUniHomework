﻿namespace VaporStore.Data.Models
{
    public enum CardType
    {
        Debit,
        Credit
    }
}