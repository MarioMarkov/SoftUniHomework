﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P03_FootballBetting.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-9JPDD1J;Database=FootballBetting;Integrated Security=True";
    }
}
