<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_99b2a225cb70aa4a8d48984f92fa0c34ec0fea32a96ff1e63d94ed7465a2ded8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5dbb2b47c91cb562c548c55e055b6a234dd3dbdf2c50247ed109356b481a10c8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5dbb2b47c91cb562c548c55e055b6a234dd3dbdf2c50247ed109356b481a10c8->enter($__internal_5dbb2b47c91cb562c548c55e055b6a234dd3dbdf2c50247ed109356b481a10c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_56b3883f84a42ef3d9607ec77cf4986c4e224cb6405e1f7d189d58068dd89fe9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56b3883f84a42ef3d9607ec77cf4986c4e224cb6405e1f7d189d58068dd89fe9->enter($__internal_56b3883f84a42ef3d9607ec77cf4986c4e224cb6405e1f7d189d58068dd89fe9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5dbb2b47c91cb562c548c55e055b6a234dd3dbdf2c50247ed109356b481a10c8->leave($__internal_5dbb2b47c91cb562c548c55e055b6a234dd3dbdf2c50247ed109356b481a10c8_prof);

        
        $__internal_56b3883f84a42ef3d9607ec77cf4986c4e224cb6405e1f7d189d58068dd89fe9->leave($__internal_56b3883f84a42ef3d9607ec77cf4986c4e224cb6405e1f7d189d58068dd89fe9_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_485f4401117a6a3da4335cd2d05d43c308938449ed1033218e04059781ef24f1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_485f4401117a6a3da4335cd2d05d43c308938449ed1033218e04059781ef24f1->enter($__internal_485f4401117a6a3da4335cd2d05d43c308938449ed1033218e04059781ef24f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_50ec44920dbd5aa3c23cef469fa4726c22faf8ae3f6ecb8c438fda1721bb137f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50ec44920dbd5aa3c23cef469fa4726c22faf8ae3f6ecb8c438fda1721bb137f->enter($__internal_50ec44920dbd5aa3c23cef469fa4726c22faf8ae3f6ecb8c438fda1721bb137f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_50ec44920dbd5aa3c23cef469fa4726c22faf8ae3f6ecb8c438fda1721bb137f->leave($__internal_50ec44920dbd5aa3c23cef469fa4726c22faf8ae3f6ecb8c438fda1721bb137f_prof);

        
        $__internal_485f4401117a6a3da4335cd2d05d43c308938449ed1033218e04059781ef24f1->leave($__internal_485f4401117a6a3da4335cd2d05d43c308938449ed1033218e04059781ef24f1_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_08f0ea8d5fc39f7add9d68da8332c93e54bc97516be0f60542561b3b619cb6c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_08f0ea8d5fc39f7add9d68da8332c93e54bc97516be0f60542561b3b619cb6c0->enter($__internal_08f0ea8d5fc39f7add9d68da8332c93e54bc97516be0f60542561b3b619cb6c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_7d45e456377d4fc3f56221e08777be5d11867bd76c5e29701e5615b87357383f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d45e456377d4fc3f56221e08777be5d11867bd76c5e29701e5615b87357383f->enter($__internal_7d45e456377d4fc3f56221e08777be5d11867bd76c5e29701e5615b87357383f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_7d45e456377d4fc3f56221e08777be5d11867bd76c5e29701e5615b87357383f->leave($__internal_7d45e456377d4fc3f56221e08777be5d11867bd76c5e29701e5615b87357383f_prof);

        
        $__internal_08f0ea8d5fc39f7add9d68da8332c93e54bc97516be0f60542561b3b619cb6c0->leave($__internal_08f0ea8d5fc39f7add9d68da8332c93e54bc97516be0f60542561b3b619cb6c0_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_c0618861259d1e7dbf3fd442968701b95f4bdc8f45b864d0a027c5ab8bfe77c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c0618861259d1e7dbf3fd442968701b95f4bdc8f45b864d0a027c5ab8bfe77c0->enter($__internal_c0618861259d1e7dbf3fd442968701b95f4bdc8f45b864d0a027c5ab8bfe77c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_c62a984caf6641237cbd1ed35b3e35e94d064e43f47306c553e6dbefdf0238a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c62a984caf6641237cbd1ed35b3e35e94d064e43f47306c553e6dbefdf0238a6->enter($__internal_c62a984caf6641237cbd1ed35b3e35e94d064e43f47306c553e6dbefdf0238a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_c62a984caf6641237cbd1ed35b3e35e94d064e43f47306c553e6dbefdf0238a6->leave($__internal_c62a984caf6641237cbd1ed35b3e35e94d064e43f47306c553e6dbefdf0238a6_prof);

        
        $__internal_c0618861259d1e7dbf3fd442968701b95f4bdc8f45b864d0a027c5ab8bfe77c0->leave($__internal_c0618861259d1e7dbf3fd442968701b95f4bdc8f45b864d0a027c5ab8bfe77c0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\Users\\PC\\Desktop\\PHP-Calc\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
