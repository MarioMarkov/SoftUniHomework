<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_d496044effa4cc39ce51801babe801f9942ccc5fec27a124c696ada197249fa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_51daf606632f050ffbcc695b5a23db176125c3f6362d6c76db12c908c9b6bdcc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_51daf606632f050ffbcc695b5a23db176125c3f6362d6c76db12c908c9b6bdcc->enter($__internal_51daf606632f050ffbcc695b5a23db176125c3f6362d6c76db12c908c9b6bdcc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_63ec9e4517f1910e96f536b6cc577ba3d29d7206038dbd12916027df2b2d4a42 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63ec9e4517f1910e96f536b6cc577ba3d29d7206038dbd12916027df2b2d4a42->enter($__internal_63ec9e4517f1910e96f536b6cc577ba3d29d7206038dbd12916027df2b2d4a42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_51daf606632f050ffbcc695b5a23db176125c3f6362d6c76db12c908c9b6bdcc->leave($__internal_51daf606632f050ffbcc695b5a23db176125c3f6362d6c76db12c908c9b6bdcc_prof);

        
        $__internal_63ec9e4517f1910e96f536b6cc577ba3d29d7206038dbd12916027df2b2d4a42->leave($__internal_63ec9e4517f1910e96f536b6cc577ba3d29d7206038dbd12916027df2b2d4a42_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_0bf4a72ef1459bf7382861dd1fef3d2378def3f4b8eb5979674954e819154d76 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0bf4a72ef1459bf7382861dd1fef3d2378def3f4b8eb5979674954e819154d76->enter($__internal_0bf4a72ef1459bf7382861dd1fef3d2378def3f4b8eb5979674954e819154d76_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_583444218c37e3020f4ccc6cd51332159bcd034e21e04885bf607b339948c2b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_583444218c37e3020f4ccc6cd51332159bcd034e21e04885bf607b339948c2b4->enter($__internal_583444218c37e3020f4ccc6cd51332159bcd034e21e04885bf607b339948c2b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_583444218c37e3020f4ccc6cd51332159bcd034e21e04885bf607b339948c2b4->leave($__internal_583444218c37e3020f4ccc6cd51332159bcd034e21e04885bf607b339948c2b4_prof);

        
        $__internal_0bf4a72ef1459bf7382861dd1fef3d2378def3f4b8eb5979674954e819154d76->leave($__internal_0bf4a72ef1459bf7382861dd1fef3d2378def3f4b8eb5979674954e819154d76_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_0b1a9e47b7ddb773789c30221112e2ca31954acef93640afa8f567f002fbd9ac = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0b1a9e47b7ddb773789c30221112e2ca31954acef93640afa8f567f002fbd9ac->enter($__internal_0b1a9e47b7ddb773789c30221112e2ca31954acef93640afa8f567f002fbd9ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_3fab1abac87d7771c42756798ff53d2cb989479ef9f067f7739d2c7d1e08b2d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3fab1abac87d7771c42756798ff53d2cb989479ef9f067f7739d2c7d1e08b2d1->enter($__internal_3fab1abac87d7771c42756798ff53d2cb989479ef9f067f7739d2c7d1e08b2d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_3fab1abac87d7771c42756798ff53d2cb989479ef9f067f7739d2c7d1e08b2d1->leave($__internal_3fab1abac87d7771c42756798ff53d2cb989479ef9f067f7739d2c7d1e08b2d1_prof);

        
        $__internal_0b1a9e47b7ddb773789c30221112e2ca31954acef93640afa8f567f002fbd9ac->leave($__internal_0b1a9e47b7ddb773789c30221112e2ca31954acef93640afa8f567f002fbd9ac_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_f6737489e1b5e6869e136d2b57b5f585ef2cf683300684bb0740cabc31cc61c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f6737489e1b5e6869e136d2b57b5f585ef2cf683300684bb0740cabc31cc61c0->enter($__internal_f6737489e1b5e6869e136d2b57b5f585ef2cf683300684bb0740cabc31cc61c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_d15ce7e8172cef0d90bf4d8d9b2dbacb5a991dc47decd641f72482c56651ecbe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d15ce7e8172cef0d90bf4d8d9b2dbacb5a991dc47decd641f72482c56651ecbe->enter($__internal_d15ce7e8172cef0d90bf4d8d9b2dbacb5a991dc47decd641f72482c56651ecbe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_d15ce7e8172cef0d90bf4d8d9b2dbacb5a991dc47decd641f72482c56651ecbe->leave($__internal_d15ce7e8172cef0d90bf4d8d9b2dbacb5a991dc47decd641f72482c56651ecbe_prof);

        
        $__internal_f6737489e1b5e6869e136d2b57b5f585ef2cf683300684bb0740cabc31cc61c0->leave($__internal_f6737489e1b5e6869e136d2b57b5f585ef2cf683300684bb0740cabc31cc61c0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\Users\\PC\\Desktop\\PHP-Calc\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
