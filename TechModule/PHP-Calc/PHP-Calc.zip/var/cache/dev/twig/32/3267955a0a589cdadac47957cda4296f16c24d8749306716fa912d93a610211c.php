<?php

/* base.html.twig */
class __TwigTemplate_4bbe4cb00ce6f8d465c8dd6727bc2b9ec28634a7580dd9013cb65806d5629e1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_30e464e38aabdb63ab64bf9778da2102a393469a7469d2e946591e81d3c2eced = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_30e464e38aabdb63ab64bf9778da2102a393469a7469d2e946591e81d3c2eced->enter($__internal_30e464e38aabdb63ab64bf9778da2102a393469a7469d2e946591e81d3c2eced_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_1dc859a41367a7b6c2565d7c80e728c372885d99c0f3f1d4fa136ae4c653ccfe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1dc859a41367a7b6c2565d7c80e728c372885d99c0f3f1d4fa136ae4c653ccfe->enter($__internal_1dc859a41367a7b6c2565d7c80e728c372885d99c0f3f1d4fa136ae4c653ccfe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>

";
        // line 50
        $this->displayBlock('footer', $context, $blocks);
        // line 57
        echo "
";
        // line 58
        $this->displayBlock('javascripts', $context, $blocks);
        // line 64
        echo "
</body>
</html>
";
        
        $__internal_30e464e38aabdb63ab64bf9778da2102a393469a7469d2e946591e81d3c2eced->leave($__internal_30e464e38aabdb63ab64bf9778da2102a393469a7469d2e946591e81d3c2eced_prof);

        
        $__internal_1dc859a41367a7b6c2565d7c80e728c372885d99c0f3f1d4fa136ae4c653ccfe->leave($__internal_1dc859a41367a7b6c2565d7c80e728c372885d99c0f3f1d4fa136ae4c653ccfe_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_052e96161cae517381f4a8dc70a03acd4d6303bd5e82492d18d7d2cd2e0575d8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_052e96161cae517381f4a8dc70a03acd4d6303bd5e82492d18d7d2cd2e0575d8->enter($__internal_052e96161cae517381f4a8dc70a03acd4d6303bd5e82492d18d7d2cd2e0575d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_acf4c61363692235fe9da8662535618230ee028cdc5d993cf53d426e92a28f8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_acf4c61363692235fe9da8662535618230ee028cdc5d993cf53d426e92a28f8d->enter($__internal_acf4c61363692235fe9da8662535618230ee028cdc5d993cf53d426e92a28f8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_acf4c61363692235fe9da8662535618230ee028cdc5d993cf53d426e92a28f8d->leave($__internal_acf4c61363692235fe9da8662535618230ee028cdc5d993cf53d426e92a28f8d_prof);

        
        $__internal_052e96161cae517381f4a8dc70a03acd4d6303bd5e82492d18d7d2cd2e0575d8->leave($__internal_052e96161cae517381f4a8dc70a03acd4d6303bd5e82492d18d7d2cd2e0575d8_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_5983e8aab35cadebc66666abd1c40a7d4634501480c78d69c4abc8560a8b9e64 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5983e8aab35cadebc66666abd1c40a7d4634501480c78d69c4abc8560a8b9e64->enter($__internal_5983e8aab35cadebc66666abd1c40a7d4634501480c78d69c4abc8560a8b9e64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_f98efc41a0203743a44c6fa3efd67fa125c990e08dcbed7f7c7cb799274dfbbb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f98efc41a0203743a44c6fa3efd67fa125c990e08dcbed7f7c7cb799274dfbbb->enter($__internal_f98efc41a0203743a44c6fa3efd67fa125c990e08dcbed7f7c7cb799274dfbbb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_f98efc41a0203743a44c6fa3efd67fa125c990e08dcbed7f7c7cb799274dfbbb->leave($__internal_f98efc41a0203743a44c6fa3efd67fa125c990e08dcbed7f7c7cb799274dfbbb_prof);

        
        $__internal_5983e8aab35cadebc66666abd1c40a7d4634501480c78d69c4abc8560a8b9e64->leave($__internal_5983e8aab35cadebc66666abd1c40a7d4634501480c78d69c4abc8560a8b9e64_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_35d2bd1e1d9fa65e5d6aea8c028c68e7ad7f5b37422cfd608f5f750b38fba231 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_35d2bd1e1d9fa65e5d6aea8c028c68e7ad7f5b37422cfd608f5f750b38fba231->enter($__internal_35d2bd1e1d9fa65e5d6aea8c028c68e7ad7f5b37422cfd608f5f750b38fba231_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_63355b81fe910ab20b49180aa1ca580dda9e7311cb6bf5100e34e507ef4789ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63355b81fe910ab20b49180aa1ca580dda9e7311cb6bf5100e34e507ef4789ad->enter($__internal_63355b81fe910ab20b49180aa1ca580dda9e7311cb6bf5100e34e507ef4789ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_63355b81fe910ab20b49180aa1ca580dda9e7311cb6bf5100e34e507ef4789ad->leave($__internal_63355b81fe910ab20b49180aa1ca580dda9e7311cb6bf5100e34e507ef4789ad_prof);

        
        $__internal_35d2bd1e1d9fa65e5d6aea8c028c68e7ad7f5b37422cfd608f5f750b38fba231->leave($__internal_35d2bd1e1d9fa65e5d6aea8c028c68e7ad7f5b37422cfd608f5f750b38fba231_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_348b968d25a6272d3d8e4aa2b41a1ddc182877fe82c1396a409f7e233533933d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_348b968d25a6272d3d8e4aa2b41a1ddc182877fe82c1396a409f7e233533933d->enter($__internal_348b968d25a6272d3d8e4aa2b41a1ddc182877fe82c1396a409f7e233533933d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_55a99a7723cb0629362b7ddadeab662c738202a106feb0aeb78dba267b23fb8e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_55a99a7723cb0629362b7ddadeab662c738202a106feb0aeb78dba267b23fb8e->enter($__internal_55a99a7723cb0629362b7ddadeab662c738202a106feb0aeb78dba267b23fb8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_55a99a7723cb0629362b7ddadeab662c738202a106feb0aeb78dba267b23fb8e->leave($__internal_55a99a7723cb0629362b7ddadeab662c738202a106feb0aeb78dba267b23fb8e_prof);

        
        $__internal_348b968d25a6272d3d8e4aa2b41a1ddc182877fe82c1396a409f7e233533933d->leave($__internal_348b968d25a6272d3d8e4aa2b41a1ddc182877fe82c1396a409f7e233533933d_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_cd64eaa2a2a5d29b9b73e1767502fea90165fa661b2dbbe96e411b1e6de78761 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cd64eaa2a2a5d29b9b73e1767502fea90165fa661b2dbbe96e411b1e6de78761->enter($__internal_cd64eaa2a2a5d29b9b73e1767502fea90165fa661b2dbbe96e411b1e6de78761_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_6cce9f718a5f0aa16afae76fb46438893ba440a98afabf91462903256667b0d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6cce9f718a5f0aa16afae76fb46438893ba440a98afabf91462903256667b0d9->enter($__internal_6cce9f718a5f0aa16afae76fb46438893ba440a98afabf91462903256667b0d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_6cce9f718a5f0aa16afae76fb46438893ba440a98afabf91462903256667b0d9->leave($__internal_6cce9f718a5f0aa16afae76fb46438893ba440a98afabf91462903256667b0d9_prof);

        
        $__internal_cd64eaa2a2a5d29b9b73e1767502fea90165fa661b2dbbe96e411b1e6de78761->leave($__internal_cd64eaa2a2a5d29b9b73e1767502fea90165fa661b2dbbe96e411b1e6de78761_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_0e535aefc0916b032b494f6545ff2a1affdeac96ef3ab467a45422ed44427557 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0e535aefc0916b032b494f6545ff2a1affdeac96ef3ab467a45422ed44427557->enter($__internal_0e535aefc0916b032b494f6545ff2a1affdeac96ef3ab467a45422ed44427557_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_5423a5567af61fb6e5466019fff2cf4b2c66c3cb36be4f77d2d0222a09103cfa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5423a5567af61fb6e5466019fff2cf4b2c66c3cb36be4f77d2d0222a09103cfa->enter($__internal_5423a5567af61fb6e5466019fff2cf4b2c66c3cb36be4f77d2d0222a09103cfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_5423a5567af61fb6e5466019fff2cf4b2c66c3cb36be4f77d2d0222a09103cfa->leave($__internal_5423a5567af61fb6e5466019fff2cf4b2c66c3cb36be4f77d2d0222a09103cfa_prof);

        
        $__internal_0e535aefc0916b032b494f6545ff2a1affdeac96ef3ab467a45422ed44427557->leave($__internal_0e535aefc0916b032b494f6545ff2a1affdeac96ef3ab467a45422ed44427557_prof);

    }

    // line 50
    public function block_footer($context, array $blocks = array())
    {
        $__internal_407c7cfb475614556e472fe313a607f87d091b5c359691d9fd984ff86acb81e0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_407c7cfb475614556e472fe313a607f87d091b5c359691d9fd984ff86acb81e0->enter($__internal_407c7cfb475614556e472fe313a607f87d091b5c359691d9fd984ff86acb81e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_fcb34eb0d8fa83d9e123fb53fbe59a4cc38ee0e5f3685dfdb67885e818a6aee5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fcb34eb0d8fa83d9e123fb53fbe59a4cc38ee0e5f3685dfdb67885e818a6aee5->enter($__internal_fcb34eb0d8fa83d9e123fb53fbe59a4cc38ee0e5f3685dfdb67885e818a6aee5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 51
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_fcb34eb0d8fa83d9e123fb53fbe59a4cc38ee0e5f3685dfdb67885e818a6aee5->leave($__internal_fcb34eb0d8fa83d9e123fb53fbe59a4cc38ee0e5f3685dfdb67885e818a6aee5_prof);

        
        $__internal_407c7cfb475614556e472fe313a607f87d091b5c359691d9fd984ff86acb81e0->leave($__internal_407c7cfb475614556e472fe313a607f87d091b5c359691d9fd984ff86acb81e0_prof);

    }

    // line 58
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_b2a735330f20e111dafeeff456a82730e338706aada29788a08507f9a4899476 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2a735330f20e111dafeeff456a82730e338706aada29788a08507f9a4899476->enter($__internal_b2a735330f20e111dafeeff456a82730e338706aada29788a08507f9a4899476_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_a1338d1b0bda27c0bfe55252e224f24d67ce66ee702a6144a0b2d832c91f5627 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a1338d1b0bda27c0bfe55252e224f24d67ce66ee702a6144a0b2d832c91f5627->enter($__internal_a1338d1b0bda27c0bfe55252e224f24d67ce66ee702a6144a0b2d832c91f5627_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 59
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_a1338d1b0bda27c0bfe55252e224f24d67ce66ee702a6144a0b2d832c91f5627->leave($__internal_a1338d1b0bda27c0bfe55252e224f24d67ce66ee702a6144a0b2d832c91f5627_prof);

        
        $__internal_b2a735330f20e111dafeeff456a82730e338706aada29788a08507f9a4899476->leave($__internal_b2a735330f20e111dafeeff456a82730e338706aada29788a08507f9a4899476_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 62,  275 => 61,  271 => 60,  266 => 59,  257 => 58,  242 => 51,  233 => 50,  216 => 44,  204 => 45,  202 => 44,  198 => 42,  189 => 41,  166 => 26,  160 => 22,  151 => 21,  134 => 19,  122 => 14,  117 => 13,  108 => 12,  90 => 11,  77 => 64,  75 => 58,  72 => 57,  70 => 50,  66 => 48,  64 => 41,  60 => 39,  58 => 21,  53 => 19,  46 => 16,  44 => 12,  40 => 11,  33 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
", "base.html.twig", "C:\\Users\\PC\\Desktop\\PHP-Calc\\app\\Resources\\views\\base.html.twig");
    }
}
